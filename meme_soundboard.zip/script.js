const audio = document.getElementById('sahur');
let loopInterval = null;

function playSound() {
  audio.currentTime = 0;
  audio.play();

  clearInterval(loopInterval);
  loopInterval = setInterval(() => {
    if (audio.currentTime >= 6) {
      audio.currentTime = 0;
      audio.play();
    }
  }, 100);
}

function stopSound() {
  audio.pause();
  audio.currentTime = 0;
  clearInterval(loopInterval);
}
